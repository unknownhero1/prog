import requests
#import xml.etree.ElementTree
from xml.etree import ElementTree
import xmltodict
#1 - create company and get company ID
url="https://soap.qa-test.csssr.com/ws/soap.wsdl"
headers = {'content-type': 'text/xml'}
body = """<?xml version="1.0" encoding="UTF-8"?>
         <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sch="http://csssr.com/schemas">
   <soapenv:Header/>
   <soapenv:Body>
      <sch:AddCompanyRequest>
         <sch:Name>CSSSR</sch:Name>
      </sch:AddCompanyRequest>
   </soapenv:Body>
</soapenv:Envelope>"""

response = requests.post(url,data=body,headers=headers)
root = ElementTree.fromstring(response.content)

ns2="{http://csssr.com/schemas}"
for company in root.iter(f"{ns2}Id"):
    companyID = company.text
    print( 'Company ID ==', companyID)

#2 - create employee and get his ID
body = """<?xml version="1.0" encoding="UTF-8"?>
         <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sch="http://csssr.com/schemas">
   <soapenv:Header/>
   <soapenv:Body>
      <sch:AddEmployeeRequest>
         <sch:FirstName></sch:FirstName>
         <sch:LastName></sch:LastName>
         <!--Optional:-->
         <sch:MiddleName></sch:MiddleName>
      </sch:AddEmployeeRequest>
   </soapenv:Body>
</soapenv:Envelope>"""

response = requests.post(url,data=body,headers=headers)
root = ElementTree.fromstring(response.content)
for emp in root.iter(f"{ns2}Id"):
    empID = emp.text
    print( 'employee ID ==', empID)

#3 update employee
firstName = "Charles Ogier"
secondName = "comte d'Artagnan"
body = f"""<?xml version="1.0" encoding="UTF-8"?>
         <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sch="http://csssr.com/schemas">
   <soapenv:Header/>
   <soapenv:Body>
      <sch:UpdateEmployeeRequest>
         <sch:Id>{empID}</sch:Id>
         <sch:FirstName>{firstName}</sch:FirstName>
         <sch:LastName>{secondName}</sch:LastName>
         <!--Optional:-->
         <sch:MiddleName>de Batz</sch:MiddleName>
      </sch:UpdateEmployeeRequest>
   </soapenv:Body>
</soapenv:Envelope>"""

response = requests.post(url,data=body,headers=headers)


#4 add employee to company
body = f"""<?xml version="1.0" encoding="UTF-8"?>
         <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sch="http://csssr.com/schemas">
   <soapenv:Header/>
   <soapenv:Body>
      <sch:AddEmployeesToCompanyRequest>
         <sch:CompanyId>{companyID}</sch:CompanyId>
         <!--Zero or more repetitions:-->
         <sch:EmployeeId>{empID}</sch:EmployeeId>
      </sch:AddEmployeesToCompanyRequest>
   </soapenv:Body>
</soapenv:Envelope>"""

responce = requests.post(url,data=body,headers=headers)
respDict = xmltodict.parse(responce.content)
print ("company name: ", respDict['SOAP-ENV:Envelope']['SOAP-ENV:Body']['ns2:AddEmployeesToCompanyResponse']['ns2:Company']['ns2:Name'])
print ("employee name: ", respDict['SOAP-ENV:Envelope']['SOAP-ENV:Body']['ns2:AddEmployeesToCompanyResponse']['ns2:Company']['ns2:employees']['ns2:FirstName'])
print ("employee Last name: ", respDict['SOAP-ENV:Envelope']['SOAP-ENV:Body']['ns2:AddEmployeesToCompanyResponse']['ns2:Company']['ns2:employees']['ns2:LastName'])
print ("employee Middle name: ", respDict['SOAP-ENV:Envelope']['SOAP-ENV:Body']['ns2:AddEmployeesToCompanyResponse']['ns2:Company']['ns2:employees']['ns2:MiddleName'])

