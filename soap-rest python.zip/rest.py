import requests

import json
#1 - create hero
url="https://superhero.qa-test.csssr.com/superheroes/"
headers = {'content-type': 'application/json'}
jsonbody = """{
  "birthDate": "2019-02-21",
  "city": "N",
  "fullName": "",
  "gender": "F",
  "mainSkill": "M",
  "phone": "+74998884433"
}"""
response = requests.post(url, headers = headers, data = jsonbody)
if (response.status_code == 200):
    json_data = json.loads(response.text)
    heroId = json_data['id']
    print("200 OK, new hero created!")
    print("new hero number: ", heroId)

else:
    print ("FAIL creating hero!")

#2 - update hero
fullname = "Doctor Who"
city = "GALAXY!"
gender = "Mixed"
mainskill = "Travel"
phone = "+74998884433"
date = "1963-01-01"

jsonDict = {
  "birthDate": date,
  "city": city,
  "fullName": fullname,
  "gender": gender,
  "id": heroId,
  "mainSkill": mainskill,
  "phone": phone
    }
jsonbody = json.dumps(jsonDict)
urlId = f'{url}{heroId}'
print ("URL to change and check hero: ", urlId)
response = requests.put(url = urlId, headers = headers, data = jsonbody)

#3 get&check hero

#print (geturl)
response = requests.get(url = urlId)
#print(response.text)
errNum = 0
if (response.status_code == 200):
    print ("check hero started...")
    checkJson = json.loads(response.text)
    print ("ID must be:", heroId)
    print ("ID is:", checkJson['id'])
    if(checkJson['id'] == heroId):
        print("ID PASSED!")
    else:
        print("ID check failed!")
        errNum = errNum + 1

    print ("name must be:", fullname)
    print ("name is:", checkJson['fullName'])
    if(checkJson['fullName'] == fullname):
        print("fullname PASSED!")
    else:
        print("fullname check failed!")
        errNum = errNum + 1

    print ("phone must be:", phone)
    print ("phone is:", checkJson['phone'])
    if(checkJson['phone'] == phone):
        print("phone PASSED!")
    else:
        print("phone check failed!")
        errNum = errNum + 1

if (errNum == 0):
    print ("check PASSED!")
else:
    print ("check FAILED!")

