#include <cstdlib>
#include <iostream>
#include <fstream>
#include <time.h>
#include <random>
#include <wchar.h>
#include <locale.h>

using namespace std;
const int maxCap = 1000;
const int numberOfAns = 4 - 1;
#define VK_C 0x43



struct words
{
    int position;
    int wordlength;
    wint_t value[30];
};

int countRand(int a)
{
    std::random_device rd;
    std::mt19937 rng(rd());
    std::uniform_int_distribution<int> uni(1,a);   
    int b = uni(rng);
    return b;
}

words * loadFile (char path[], int * pnlcnt)
{
    char *locale = setlocale(LC_ALL, "");
    FILE *in = fopen(path, "r");
    words * voc = new words[maxCap]; // struct for text massive
    int pcnt = 0; //global letter's counter from txt massive (with endl and nl symbols)
    int lettercnt = 0; // local letter counter in each line 
    wint_t c; // letter variable
    
    while  ((c = fgetwc(in)) != WEOF) {      
        voc[* pnlcnt].value[lettercnt] = c;
        pcnt++;
        lettercnt++;
        if (c == 0x0a){
            voc[* pnlcnt].position = * pnlcnt;
            voc[* pnlcnt].wordlength = lettercnt;            
            (*pnlcnt)++;
            lettercnt = 0;
            } 
        }    
    fclose(in);
    return voc;
}

void printWord (words * voc, int wordNum)
{    int length = voc[wordNum].wordlength;
    cout << std::flush;
    freopen(NULL, "w", stdout);
    for (int i = 0; i < length; i++){
        putwchar(voc[wordNum].value[i]);
    } 
    freopen(NULL, "w", stdout);
    
}

int compareIndexes( int a, int b)
{
    if (a > b)
        return b;
    else
        return a;
}

void calcArray(int * arr, int numOfVars, int varCap, int rightAns)
{
    for (int i = 0; i <= numOfVars; i++)
    {
        int repit = -1;
        int cand = 0;
        do
        {
            repit = 0;
            cand = countRand(varCap);
            for (int y = 0; y <= i; y++)
            if ((cand == arr[y]) || (cand == rightAns))
                repit++;
//            cout << "cand - " << cand << ";";
            
        }
        while (repit != 0);
        arr[i] = cand;
//        cout << "\nansw[" << i << "] - " << arr[i] << endl;
    }
    int rightAnsPlace = countRand(numOfVars);
    arr[rightAnsPlace] = rightAns;
//    cout << "right ans = " << rightAns << endl <<
//            "right ans place = " << rightAnsPlace << endl << endl << "result array:\n";


}


int main(void)
{

    //srand(time(NULL));



        int nlcnt = 0; // lines counter in txt
    int * pnlcnt = &nlcnt;   
    words * voc1 = loadFile("vocab_for.txt", pnlcnt);
    
    int nlcnt2 = 0; // lines counter in txt
    int * pnlcnt2 = &nlcnt2;
    words * voc2 = loadFile("vocab_rus.txt", pnlcnt2);

    int   workingIndex = compareIndexes(nlcnt, nlcnt2);
    //cout << "working index = " << workingIndex << endl;

    int * answers = new int[workingIndex];
      char inpAnsChar;

  do
  {
    //system("CLS");
    int queNum = countRand(workingIndex);
    //cout  << voc1[queNum].value << "\nYour answer?..\n\n";
    printWord(voc1, queNum);  
    //freopen(NULL, "w", stdout);
    cout  << "\nYour answer?..\n\n";
    
    calcArray(answers, numberOfAns, workingIndex,  queNum);
    for (int i = 0; i <= numberOfAns; i++){
        cout << i+1 << ") ";
        printWord(voc2, answers[i]);
        //freopen(NULL, "w", stdout);
        cout << endl;
    }
    inpAnsChar = getchar();
    int inpAnsInt = inpAnsChar - 48;

    if (inpAnsInt <= numberOfAns + 1)
    {
    //cout << "\nYou entered:\n" << voc2[answers[inpAnsInt-1]].value << endl;
    if (voc1[queNum].position == voc2[answers[inpAnsInt-1]].position)
        cout << "Yes, wright!\n";
    else{
        cout << "Noooo, wrong, it's ";
        printWord(voc2, queNum);
        cout << endl;
    }
    
    getchar();
}


}
  while (inpAnsChar != '9');


}
